#include <linux/errno.h>
#include <linux/sched.h>

int is_short(pid_t pid) {
    if (pid < 0) {
        return -ESRCH;
    }

    task_t *task = find_task_by_pid(pid);

    if (task == NULL) {
        return -ESRCH;
    }

    unsigned long policy = task->policy;
    if (policy != SCHED_SHORT && policy != SCHED_SHORT_OVERDUE) {
        return -EINVAL;
    }

    return (policy == SCHED_SHORT) ? 1 : 0;
}

int short_remaining_time(pid_t pid) {
    if (pid < 0) {
        return -ESRCH;
    }

    task_t *task = find_task_by_pid(pid);

    if (task == NULL) {
        return -ESRCH;
    }

    unsigned long policy = task->policy;
    if (policy != SCHED_SHORT && policy != SCHED_SHORT_OVERDUE) {
        return -EINVAL;
    }

    return task->time_slice;
}
